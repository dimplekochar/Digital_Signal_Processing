#ifndef AUDIO_SETUP_H_
#define AUDIO_SETUP_H_

#define FFT_LENGTH  256				/* 8/16/64/128/256/512/1024 */
								/**************************HINT**********************************/
#define PING_PONG_SIZE 1234		// replace 1234 with appropriate number refer overlap and save reference material. 

#endif /*AUDIO_SETUP_H_*/
