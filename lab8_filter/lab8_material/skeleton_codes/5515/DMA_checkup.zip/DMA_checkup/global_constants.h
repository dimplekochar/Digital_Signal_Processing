#ifndef AUDIO_SETUP_H_
#define AUDIO_SETUP_H_

#define PING_PONG_SIZE 1024   // setting the length of Ping-Pong buffer

#endif /*AUDIO_SETUP_H_*/
